const getBaseUrl = () => {
    return "http://localhost:5000"
}

export default getBaseUrl;