backend code of the project
