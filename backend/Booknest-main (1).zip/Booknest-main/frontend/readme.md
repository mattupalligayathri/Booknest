frontend code of the project
