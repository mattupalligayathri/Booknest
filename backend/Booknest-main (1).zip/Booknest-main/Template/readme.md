template of the project
